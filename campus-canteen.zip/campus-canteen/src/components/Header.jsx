import { NavLink, Link } from "react-router-dom";
import { useCart } from "../context/CartContext.jsx";

export default function Header() {
  const { totalItems } = useCart();

  return (
    <header className="site-header">
      <div className="container header-inner">
        <Link to="/" className="brand" aria-label="Chai and Chaat Campus Canteen, home">
          <span className="brand-mark" aria-hidden="true">☕</span>
          <span className="brand-text">
            Chai &amp; Chaat
            <small>Campus Canteen</small>
          </span>
        </Link>

        <nav aria-label="Main navigation" className="nav">
          <NavLink to="/" end>Menu</NavLink>
          <NavLink to="/cart" aria-label={`Cart, ${totalItems} items`}>
            <span aria-hidden="true">🛒</span>
            <span>Cart</span>
            <span className="cart-count" aria-live="polite">{totalItems}</span>
          </NavLink>
        </nav>
      </div>
    </header>
  );
}
