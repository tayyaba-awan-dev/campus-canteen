import { useState } from "react";
import ItemCard from "./ItemCard.jsx";

export default function MenuList({ items, favourites, onToggleFavourite, onAddToCart }) {
  const [searchText, setSearchText] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [showFavouritesOnly, setShowFavouritesOnly] = useState(false);

  const categories = ["All", ...new Set(items.map((item) => item.category))];

  const visibleItems = items.filter((item) => {
    const query = searchText.trim().toLowerCase();
    const matchesSearch =
      query === "" ||
      item.name.toLowerCase().includes(query) ||
      item.description.toLowerCase().includes(query);
    const matchesCategory = selectedCategory === "All" || item.category === selectedCategory;
    const matchesFavourite = !showFavouritesOnly || favourites.includes(item.id);
    return matchesSearch && matchesCategory && matchesFavourite;
  });

  function resetFilters() {
    setSearchText("");
    setSelectedCategory("All");
    setShowFavouritesOnly(false);
  }

  return (
    <section aria-labelledby="menu-heading">
      <h2 id="menu-heading" className="visually-hidden">Menu items</h2>

      <div className="toolbar">
        <div className="field">
          <label htmlFor="menu-search">Search the menu</label>
          <input
            id="menu-search"
            type="search"
            placeholder="Try biryani, chai, burger…"
            value={searchText}
            onChange={(event) => setSearchText(event.target.value)}
          />
        </div>

        <button
          type="button"
          className={`btn ${showFavouritesOnly ? "btn-primary" : "btn-outline"}`}
          aria-pressed={showFavouritesOnly}
          onClick={() => setShowFavouritesOnly((value) => !value)}
        >
          ♥ Favourites ({favourites.length})
        </button>
      </div>

      <div className="chips" role="group" aria-label="Filter by category">
        {categories.map((category) => (
          <button
            key={category}
            type="button"
            className={`chip ${selectedCategory === category ? "is-active" : ""}`}
            aria-pressed={selectedCategory === category}
            onClick={() => setSelectedCategory(category)}
          >
            {category}
          </button>
        ))}
      </div>

      <p className="result-count" aria-live="polite">
        Showing {visibleItems.length} of {items.length} items
      </p>

      {visibleItems.length === 0 ? (
        <div className="state-box">
          <h3>No items match your search</h3>
          <p>Try a different word, or clear the filters to see the full menu.</p>
          <button type="button" className="btn btn-primary" onClick={resetFilters}>
            Clear filters
          </button>
        </div>
      ) : (
        <div className="grid">
          {visibleItems.map((item) => (
            <ItemCard
              key={item.id}
              item={item}
              isFavourite={favourites.includes(item.id)}
              onToggleFavourite={onToggleFavourite}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      )}
    </section>
  );
}
