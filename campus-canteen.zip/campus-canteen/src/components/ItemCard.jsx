import { Link } from "react-router-dom";
import { formatPKR, handleImageError } from "../utils/format.js";

export default function ItemCard({ item, isFavourite, onToggleFavourite, onAddToCart }) {
  return (
    <article className={`card ${item.available ? "" : "card-unavailable"}`}>
      <div className="card-image-wrap">
        <img
          src={item.image}
          alt={item.name}
          loading="lazy"
          onError={handleImageError}
          className="card-image"
        />
        <button
          type="button"
          className={`fav-btn ${isFavourite ? "is-active" : ""}`}
          onClick={() => onToggleFavourite(item.id)}
          aria-pressed={isFavourite}
          aria-label={isFavourite ? `Remove ${item.name} from favourites` : `Add ${item.name} to favourites`}
        >
          {isFavourite ? "♥" : "♡"}
        </button>
        {!item.available && <span className="badge-sold">Sold out</span>}
      </div>

      <div className="card-body">
        <p className="card-category">{item.category}</p>
        <h3 className="card-title">{item.name}</h3>
        <p className="card-desc">{item.description}</p>
        <div className="card-meta">
          <span className="price">{formatPKR(item.price)}</span>
          <span className={item.available ? "status ok" : "status no"}>
            {item.available ? "Available" : "Unavailable"}
          </span>
        </div>
        <div className="card-actions">
          <Link to={`/item/${item.id}`} className="btn btn-outline">View details</Link>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => onAddToCart(item)}
            disabled={!item.available}
          >
            Add to cart
          </button>
        </div>
      </div>
    </article>
  );
}
