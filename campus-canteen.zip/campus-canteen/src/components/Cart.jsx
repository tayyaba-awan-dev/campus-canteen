import { Link } from "react-router-dom";
import { formatPKR, handleImageError } from "../utils/format.js";

export default function Cart({ items, totalPrice, onUpdateQuantity, onRemove, onClear }) {
  if (items.length === 0) {
    return (
      <div className="state-box">
        <h2>Your cart is empty</h2>
        <p>Add something hot from the menu and it will show up here.</p>
        <Link to="/" className="btn btn-primary">Browse the menu</Link>
      </div>
    );
  }

  function handlePlaceOrder() {
    window.alert("Thank you! Your order has been placed (demo only).");
    onClear();
  }

  return (
    <div className="cart-layout">
      <ul className="cart-list">
        {items.map((line) => (
          <li key={line.id} className="cart-row">
            <img src={line.image} alt={line.name} onError={handleImageError} className="cart-thumb" />

            <div className="cart-info">
              <Link to={`/item/${line.id}`} className="cart-name">{line.name}</Link>
              <span className="muted">{formatPKR(line.price)} each</span>
            </div>

            <div className="qty" role="group" aria-label={`Quantity for ${line.name}`}>
              <button
                type="button"
                aria-label={`Decrease quantity of ${line.name}`}
                onClick={() => onUpdateQuantity(line.id, line.quantity - 1)}
              >
                −
              </button>
              <span aria-live="polite">{line.quantity}</span>
              <button
                type="button"
                aria-label={`Increase quantity of ${line.name}`}
                onClick={() => onUpdateQuantity(line.id, line.quantity + 1)}
              >
                +
              </button>
            </div>

            <p className="cart-subtotal">{formatPKR(line.price * line.quantity)}</p>

            <button
              type="button"
              className="btn btn-danger"
              onClick={() => onRemove(line.id)}
              aria-label={`Remove ${line.name} from cart`}
            >
              Remove
            </button>
          </li>
        ))}
      </ul>

      <aside className="summary" aria-label="Order summary">
        <h2>Order summary</h2>
        <dl>
          {items.map((line) => (
            <div key={line.id} className="summary-line">
              <dt>{line.name} × {line.quantity}</dt>
              <dd>{formatPKR(line.price * line.quantity)}</dd>
            </div>
          ))}
          <div className="summary-line summary-total">
            <dt>Grand total</dt>
            <dd>{formatPKR(totalPrice)}</dd>
          </div>
        </dl>
        <button type="button" className="btn btn-primary btn-block" onClick={handlePlaceOrder}>
          Place order
        </button>
        <button type="button" className="btn btn-outline btn-block" onClick={onClear}>
          Clear cart
        </button>
      </aside>
    </div>
  );
}
