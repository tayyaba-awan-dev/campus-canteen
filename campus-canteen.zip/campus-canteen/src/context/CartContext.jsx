import { createContext, useContext, useEffect, useState } from "react";

const CartContext = createContext(null);
const STORAGE_KEY = "campus-canteen-cart";

function loadSavedCart() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    const parsed = saved ? JSON.parse(saved) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function CartProvider({ children }) {
  // Each cart line: { id, name, price, image, category, quantity }
  const [cartItems, setCartItems] = useState(loadSavedCart);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cartItems));
    } catch {
      // Storage may be full or blocked; the cart still works in memory.
    }
  }, [cartItems]);

  function addToCart(item, quantity = 1) {
    if (!item.available) return;
    setCartItems((current) => {
      const existing = current.find((line) => line.id === item.id);
      if (existing) {
        return current.map((line) =>
          line.id === item.id ? { ...line, quantity: line.quantity + quantity } : line
        );
      }
      return [
        ...current,
        {
          id: item.id,
          name: item.name,
          price: item.price,
          image: item.image,
          category: item.category,
          quantity,
        },
      ];
    });
  }

  function removeFromCart(id) {
    setCartItems((current) => current.filter((line) => line.id !== id));
  }

  function updateQuantity(id, quantity) {
    if (quantity < 1) {
      removeFromCart(id);
      return;
    }
    setCartItems((current) =>
      current.map((line) => (line.id === id ? { ...line, quantity } : line))
    );
  }

  function clearCart() {
    setCartItems([]);
  }

  const totalItems = cartItems.reduce((sum, line) => sum + line.quantity, 0);
  const totalPrice = cartItems.reduce((sum, line) => sum + line.price * line.quantity, 0);

  const value = {
    cartItems,
    totalItems,
    totalPrice,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used inside a CartProvider");
  }
  return context;
}
