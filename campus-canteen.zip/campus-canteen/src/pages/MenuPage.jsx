import { useEffect, useState } from "react";
import MenuList from "../components/MenuList.jsx";
import { useCart } from "../context/CartContext.jsx";

export default function MenuPage() {
  const { addToCart } = useCart();
  const [menuItems, setMenuItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [notice, setNotice] = useState("");
  const [favourites, setFavourites] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("campus-canteen-favourites")) || [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    async function loadMenu() {
      setIsLoading(true);
      setErrorMessage("");
      try {
        const response = await fetch("/menu.json");
        if (!response.ok) {
          throw new Error(`Server replied with status ${response.status}`);
        }
        const data = await response.json();
        setMenuItems(data);
      } catch (error) {
        setErrorMessage(error.message || "Something went wrong.");
      } finally {
        setIsLoading(false);
      }
    }
    loadMenu();
  }, [reloadKey]);

  useEffect(() => {
    try {
      localStorage.setItem("campus-canteen-favourites", JSON.stringify(favourites));
    } catch {
      // Ignore storage errors; favourites still work for this visit.
    }
  }, [favourites]);

  useEffect(() => {
    if (!notice) return undefined;
    const timer = setTimeout(() => setNotice(""), 2000);
    return () => clearTimeout(timer);
  }, [notice]);

  function toggleFavourite(id) {
    setFavourites((current) =>
      current.includes(id) ? current.filter((itemId) => itemId !== id) : [...current, id]
    );
  }

  function handleAddToCart(item) {
    addToCart(item, 1);
    setNotice(`${item.name} added to cart`);
  }

  return (
    <>
      <section className="hero">
        <h1>What are you eating between lectures?</h1>
        <p>Pick your favourites, add them to the cart and skip the long queue at the counter.</p>
      </section>

      {isLoading && (
        <div className="state-box" role="status">
          <div className="spinner" aria-hidden="true" />
          <p>Loading today&apos;s menu…</p>
        </div>
      )}

      {!isLoading && errorMessage && (
        <div className="state-box state-error" role="alert">
          <h2>We couldn&apos;t load the menu</h2>
          <p>{errorMessage}</p>
          <button type="button" className="btn btn-primary" onClick={() => setReloadKey((key) => key + 1)}>
            Try again
          </button>
        </div>
      )}

      {!isLoading && !errorMessage && (
        <MenuList
          items={menuItems}
          favourites={favourites}
          onToggleFavourite={toggleFavourite}
          onAddToCart={handleAddToCart}
        />
      )}

      <div className={`toast ${notice ? "show" : ""}`} role="status" aria-live="polite">
        {notice}
      </div>
    </>
  );
}
