import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useCart } from "../context/CartContext.jsx";
import { formatPKR, handleImageError } from "../utils/format.js";

export default function ItemDetailsPage() {
  const { id } = useParams();
  const { addToCart } = useCart();
  const [item, setItem] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    async function loadItem() {
      setIsLoading(true);
      setErrorMessage("");
      setItem(null);
      try {
        const response = await fetch("/menu.json");
        if (!response.ok) {
          throw new Error(`Server replied with status ${response.status}`);
        }
        const data = await response.json();
        const found = data.find((entry) => String(entry.id) === id);
        if (!found) {
          throw new Error("We couldn't find that item on the menu.");
        }
        setItem(found);
      } catch (error) {
        setErrorMessage(error.message || "Something went wrong.");
      } finally {
        setIsLoading(false);
      }
    }
    loadItem();
  }, [id, reloadKey]);

  function handleAdd() {
    addToCart(item, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  }

  if (isLoading) {
    return (
      <div className="state-box" role="status">
        <div className="spinner" aria-hidden="true" />
        <p>Loading item…</p>
      </div>
    );
  }

  if (errorMessage) {
    return (
      <div className="state-box state-error" role="alert">
        <h1>Something went wrong</h1>
        <p>{errorMessage}</p>
        <div className="row-gap">
          <button type="button" className="btn btn-primary" onClick={() => setReloadKey((key) => key + 1)}>
            Try again
          </button>
          <Link to="/" className="btn btn-outline">Back to menu</Link>
        </div>
      </div>
    );
  }

  return (
    <article className="details">
      <Link to="/" className="back-link">← Back to menu</Link>

      <div className="details-layout">
        <img src={item.image} alt={item.name} onError={handleImageError} className="details-image" />

        <div className="details-info">
          <p className="card-category">{item.category}</p>
          <h1>{item.name}</h1>
          <p className="details-desc">{item.description}</p>
          <p className="details-price">{formatPKR(item.price)}</p>
          <p className={item.available ? "status ok" : "status no"}>
            {item.available ? "Available today" : "Unavailable right now"}
          </p>

          <div className="details-order">
            <label htmlFor="quantity">Quantity</label>
            <div className="qty">
              <button
                type="button"
                aria-label="Decrease quantity"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                disabled={!item.available}
              >
                −
              </button>
              <input
                id="quantity"
                type="number"
                min="1"
                max="20"
                value={quantity}
                disabled={!item.available}
                onChange={(event) => {
                  const value = Number(event.target.value);
                  setQuantity(Number.isNaN(value) ? 1 : Math.min(20, Math.max(1, Math.floor(value))));
                }}
              />
              <button
                type="button"
                aria-label="Increase quantity"
                onClick={() => setQuantity((q) => Math.min(20, q + 1))}
                disabled={!item.available}
              >
                +
              </button>
            </div>
          </div>

          <p className="muted">Subtotal: <strong>{formatPKR(item.price * quantity)}</strong></p>

          <div className="row-gap">
            <button type="button" className="btn btn-primary" onClick={handleAdd} disabled={!item.available}>
              {item.available ? "Add to cart" : "Sold out"}
            </button>
            <Link to="/cart" className="btn btn-outline">Go to cart</Link>
          </div>
          <p className="muted" role="status" aria-live="polite">
            {added ? `Added ${quantity} × ${item.name} to your cart.` : ""}
          </p>
        </div>
      </div>
    </article>
  );
}
