import { Routes, Route, Link } from "react-router-dom";
import Header from "./components/Header.jsx";
import MenuPage from "./pages/MenuPage.jsx";
import ItemDetailsPage from "./pages/ItemDetailsPage.jsx";
import CartPage from "./pages/CartPage.jsx";

function NotFound() {
  return (
    <div className="state-box">
      <h1>Page not found</h1>
      <p>That page is not on the menu.</p>
      <Link className="btn btn-primary" to="/">Back to menu</Link>
    </div>
  );
}

export default function App() {
  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <Header />
      <main id="main" className="container">
        <Routes>
          <Route path="/" element={<MenuPage />} />
          <Route path="/item/:id" element={<ItemDetailsPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="site-footer">
        <p>Chai &amp; Chaat Campus Canteen. Open 8:00 am to 6:00 pm, Monday to Saturday.</p>
      </footer>
    </>
  );
}
