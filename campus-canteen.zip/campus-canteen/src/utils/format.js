const pkr = new Intl.NumberFormat("en-PK", {
  style: "currency",
  currency: "PKR",
  maximumFractionDigits: 0,
});

export function formatPKR(amount) {
  return pkr.format(amount);
}

// Inline SVG shown when an image URL fails to load (works offline).
export const FALLBACK_IMAGE =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400">
      <rect width="600" height="400" fill="#e6efee"/>
      <circle cx="300" cy="190" r="70" fill="none" stroke="#0F4C5C" stroke-width="10"/>
      <circle cx="300" cy="190" r="38" fill="#F2A900"/>
      <text x="300" y="320" font-family="sans-serif" font-size="26" text-anchor="middle" fill="#0F4C5C">Image unavailable</text>
    </svg>`
  );

export function handleImageError(event) {
  event.currentTarget.onerror = null;
  event.currentTarget.src = FALLBACK_IMAGE;
}
